@echo off
REM Script para compilar un ejecutable portable con PyInstaller
REM Uso: ejecutar desde la carpeta del proyecto (donde está imagenes.py)

setlocal
echo Creando/actualizando entorno y dependencias...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt pyinstaller

echo Ejecutando PyInstaller (un solo archivo)...
echo Generando icono...
python generate_icon.py
set ICON=camera_scissors.ico
echo Ejecutando PyInstaller (un solo archivo) con icono %ICON%...
python -m PyInstaller --onefile --name ajustarImagenesTienda --icon %ICON% imagenes.py

if exist dist\ajustarImagenesTienda.exe (
    if not exist dist_exe mkdir dist_exe
    move /Y "dist\ajustarImagenesTienda.exe" dist_exe\ >nul
    echo Ejecutable creado en dist_exe\ajustarImagenesTienda.exe
) else (
    echo No se encontró el ejecutable en dist\. Revisa la salida de PyInstaller.
)

endlocal

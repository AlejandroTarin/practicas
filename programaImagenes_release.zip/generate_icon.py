from PIL import Image, ImageDraw

def draw_icon(path='camera_scissors.ico'):
    size = 256
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Camera body
    body_box = (32, 64, 224, 176)
    draw.rounded_rectangle(body_box, radius=18, fill=(30,30,30,255))

    # Top hump
    draw.rectangle((72, 32, 184, 72), fill=(40,40,40,255))

    # Lens
    draw.ellipse((88, 88, 168, 168), fill=(200,200,200,255))
    draw.ellipse((108, 108, 148, 148), fill=(60,60,60,255))

    # Scissors - simple stylized blades over the lens
    # Left blade
    draw.polygon([(120,120),(90,90),(110,86),(138,114)], fill=(220,40,40,230))
    # Right blade
    draw.polygon([(136,136),(166,166),(146,170),(118,142)], fill=(220,40,40,230))

    # Handles (circles)
    draw.ellipse((76,76,100,100), outline=(220,40,40,255), width=8)
    draw.ellipse((156,156,180,180), outline=(220,40,40,255), width=8)

    # Save as ICO with multiple sizes
    sizes = [(256,256),(128,128),(64,64),(48,48),(32,32),(16,16)]
    img.save(path, format='ICO', sizes=sizes)

if __name__ == '__main__':
    draw_icon()
    print('Icono creado: camera_scissors.ico')

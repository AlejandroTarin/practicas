@echo off
REM Start script: si existe el ejecutable, lo ejecuta; si no, usa el script Python
SETLOCAL
cd /d "%~dp0"
IF EXIST dist_exe\ajustarImagenesTienda.exe (
    echo Ejecutando ejecutable...
    REM Asegurar que dist_exe\in y dist_exe\out existen
    if not exist dist_exe\in mkdir dist_exe\in
    if not exist dist_exe\out mkdir dist_exe\out
    dist_exe\ajustarImagenesTienda.exe
) ELSE (
    echo Ejecutando script Python (procesará carpeta in -> out)...
    python imagenes.py
)
echo.
echo Pulsa una tecla para cerrar esta ventana.
pause >nul
ENDLOCAL

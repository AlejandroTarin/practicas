import argparse
import sys
import time
from pathlib import Path
import cv2
import numpy as np
from PIL import Image
import os
import glob


def recortar_y_centrar(ruta_entrada, ruta_salida, margen_pixeles=50):
    # 1. Cargar la imagen con OpenCV
    img = cv2.imread(ruta_entrada)
    if img is None:
        print("No se pudo cargar la imagen:", ruta_entrada)
        return False

    # 2. Convertir a escala de grises y aplicar umbral para detectar el fondo
    gris = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Suponiendo fondo claro (si es fondo oscuro, usa cv2.THRESH_BINARY)
    _, umbral = cv2.threshold(gris, 240, 255, cv2.THRESH_BINARY_INV)

    # 3. Encontrar los contornos del objeto principal
    contornos_data = cv2.findContours(umbral, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    # Compatibilidad con diferentes versiones de OpenCV
    if len(contornos_data) == 3:
        _, contornos, _ = contornos_data
    else:
        contornos, _ = contornos_data

    if not contornos:
        print("No se detectó ningún objeto para centrar.")
        return False

    # Unir todos los contornos en una matriz Nx2 de puntos
    try:
        todos_los_puntos = np.vstack([c.reshape(-1, 2) for c in contornos])
    except Exception:
        # Fallback si las formas son inesperadas
        todos_los_puntos = np.concatenate(contornos).reshape(-1, 2)

    x, y, w, h = cv2.boundingRect(todos_los_puntos)

    # 4. Calcular el centro del sujeto y el tamaño del nuevo lienzo cuadrado
    centro_x = int(x + w // 2)
    centro_y = int(y + h // 2)
    lado_mayor = int(max(w, h) + (margen_pixeles * 2))

    # 5. Abrir la imagen original con Pillow para un recorte limpio
    img_pil = Image.open(ruta_entrada)
    ancho_orig, alto_orig = img_pil.size

    # Calcular las coordenadas de corte manteniendo al sujeto en el centro
    half = lado_mayor // 2
    izq = int(max(0, centro_x - half))
    sup = int(max(0, centro_y - half))
    der = int(min(ancho_orig, centro_x + half))
    inf = int(min(alto_orig, centro_y + half))

    # Si el recorte quedó vacío, usar la imagen completa como fallback
    if der <= izq or inf <= sup:
        print("Recorte calculado inválido, se usará la imagen completa como fallback.")
        imagen_recortada = img_pil.copy()
    else:
        imagen_recortada = img_pil.crop((izq, sup, der, inf))

    imagen_recortada.save(ruta_salida)
    print(f"Imagen procesada con éxito y guardada en: {ruta_salida}")
    return True


def main():
    parser = argparse.ArgumentParser(description="Recorta y centra el sujeto principal de una imagen.")
    parser.add_argument("input", nargs='?', default=None, help="Ruta de la imagen o carpeta de entrada (opcional). Si se omite, usa la carpeta 'in' en el directorio del programa.")
    parser.add_argument("output", nargs='?', default=None, help="Ruta de la imagen de salida (archivo o carpeta). Si se omite, usa la carpeta 'out' en el directorio del programa.")
    parser.add_argument("--margen", type=int, default=50, help="Margen en píxeles alrededor del sujeto (por defecto 50)")
    parser.add_argument("--suffix", default="_copia", help="Sufijo que se añadirá al nombre de archivo de salida (por defecto '_copia')")
    args = parser.parse_args()

    # Modo por defecto: si no se pasan argumentos, usar carpetas 'in' y 'out' en el directorio del ejecutable
    # Cuando se ejecuta desde un .exe generado por PyInstaller, `sys.frozen` es True
    if getattr(sys, 'frozen', False):
        base_dir = os.path.dirname(sys.executable)
    else:
        base_dir = os.path.dirname(os.path.abspath(__file__))
    default_in = os.path.join(base_dir, "in")
    default_out = os.path.join(base_dir, "out")

    if args.input is None:
        args.input = default_in
    if args.output is None:
        args.output = default_out

    # Asegurar que las carpetas existen
    try:
        if not os.path.exists(args.input):
            if os.path.splitext(args.input)[1] == "":
                os.makedirs(args.input, exist_ok=True)
        if not os.path.exists(args.output):
            os.makedirs(args.output, exist_ok=True)
    except Exception:
        pass

    # Si la entrada es un directorio, procesar todos los archivos de imagen dentro
    if os.path.isdir(args.input):
        patrones = ["*.jpg", "*.jpeg", "*.png", "*.bmp", "*.tif", "*.tiff", "*.webp"]
        archivos = []
        for p in patrones:
            archivos.extend(glob.glob(os.path.join(args.input, p)))

        # Si no hay imágenes, pedir al usuario que coloque imágenes en la carpeta 'in'
        if not archivos:
            print("No se encontraron imágenes en la carpeta:", args.input)
            print("Por favor coloca las imágenes en la carpeta 'in'. Pulsa Enter para reintentar o Ctrl+C para cancelar.")
            try:
                while True:
                    input()
                    archivos = []
                    for p in patrones:
                        archivos.extend(glob.glob(os.path.join(args.input, p)))
                    if archivos:
                        break
                    print("Aún no se encontraron imágenes. Añade archivos a la carpeta 'in' y pulsa Enter para reintentar, o Ctrl+C para cancelar.")
            except KeyboardInterrupt:
                print("Procesamiento cancelado por el usuario.")
                raise SystemExit(1)

        # Visual feedback for batch processing
        print("\n=============================================")
        print("AjustarImagenesTienda — Procesamiento por lotes")
        print(f"Entrada: {args.input}")
        print(f"Salida:  {args.output}")
        print(f"Archivos encontrados: {len(archivos)}")
        print("=============================================\n")

        # Pause for user to confirm (helps avoid accidental runs)
        try:
            input("Pulsa Enter para comenzar el procesamiento o Ctrl+C para cancelar...")
        except KeyboardInterrupt:
            print("Procesamiento cancelado por el usuario.")
            return

        # Determinar carpeta de salida
        if args.output:
            out_dir = args.output
            if not os.path.exists(out_dir):
                os.makedirs(out_dir, exist_ok=True)
        else:
            out_dir = args.input

        procesados = 0
        inicio = time.time()
        total = len(archivos)

        def fmt_time(s):
            if s < 60:
                return f"{int(s)}s"
            m = int(s // 60)
            sec = int(s % 60)
            return f"{m}m{sec}s"

        BAR_WIDTH = 32
        for idx, fichero in enumerate(archivos, start=1):
            base = os.path.splitext(os.path.basename(fichero))[0]
            ext = os.path.splitext(fichero)[1]
            salida = os.path.join(out_dir, f"{base}{args.suffix}{ext}")

            # Print simple action line
            print(f"[{idx}/{total}] Procesando: {os.path.basename(fichero)} -> {os.path.basename(salida)}")

            ok = recortar_y_centrar(fichero, salida, margen_pixeles=args.margen)
            if ok:
                procesados += 1
                status = "OK"
            else:
                status = "ERR"

            # Progress bar
            elapsed = time.time() - inicio
            avg = elapsed / idx if idx else 0
            eta = avg * (total - idx)
            pct = int((idx / total) * 100)
            filled = int((idx / total) * BAR_WIDTH)
            bar = "#" * filled + "-" * (BAR_WIDTH - filled)
            sys.stdout.write(f"\r[{bar}] {pct}%  {idx}/{total}  ETA: {fmt_time(eta)}  Últ: {status}   ")
            sys.stdout.flush()

        # Finish progress line
        print()  
        dur = time.time() - inicio
        print("\nResumen:")
        print(f"  Procesadas: {procesados}/{total} en {dur:.1f}s")
        print("Fin del procesamiento. Revisa la carpeta de salida para las imágenes modificadas.")
        return

    # Si la entrada es un archivo individual
    input_path = args.input
    output_path = args.output
    if not output_path:
        # construir nombre de salida junto a la entrada
        dirn = os.path.dirname(input_path) or '.'
        base = os.path.splitext(os.path.basename(input_path))[0]
        ext = os.path.splitext(input_path)[1]
        output_path = os.path.join(dirn, f"{base}{args.suffix}{ext}")

    # Si output es una carpeta existente, usarla
    if os.path.isdir(output_path):
        base = os.path.splitext(os.path.basename(input_path))[0]
        ext = os.path.splitext(input_path)[1]
        output_path = os.path.join(output_path, f"{base}{args.suffix}{ext}")

    success = recortar_y_centrar(input_path, output_path, margen_pixeles=args.margen)
    if not success:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

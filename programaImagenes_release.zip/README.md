# Ajustar imágenes tienda — Empaquetado a ejecutable

Este repositorio contiene `imagenes.py`, un script que recorta y centra el sujeto principal de imágenes.

Objetivo: crear un ejecutable portable llamado "ajustarImagenesTienda" para Windows.

Prerequisitos
- Python 3.8+ instalado en Windows
- Conexión a Internet para instalar dependencias (solo para el build)

Flujo simple para el usuario

1. Copia tus imágenes en la carpeta `in` (en la misma carpeta que este `README.md`).
2. Ejecuta `start.bat` (doble clic) — si existe el ejecutable, se ejecutará; si no, se ejecutará el script Python.

Al ejecutar verás mensajes en la consola que indican:
- la carpeta de entrada (`in`) y de salida (`out`)
- cuántas imágenes se han encontrado
- un mensaje de confirmación para iniciar el procesamiento
- el progreso por archivo (ej. `[3/10] Procesando: foto1.jpg`)

Esto ofrece feedback claro para que el usuario sepa exactamente qué hace el programa y pueda cancelar antes de empezar si lo desea.

Nota: para crear el ejecutable (opcional), usa `build_exe.bat` como se explica más abajo. El `.exe` se moverá a `dist_exe\` con el nombre `ajustarImagenesTienda.exe`.

Icono incluido

El repositorio incluye un script `generate_icon.py` que genera un icono estilo "cámara con tijeras" (`camera_scissors.ico`). `build_exe.bat` ejecuta este script automáticamente y usa el icono al crear el `.exe`.

Comandos manuales (alternativa)

```powershell
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt pyinstaller
pyinstaller --onefile --name ajustarImagenesTienda imagenes.py
```

Uso del ejecutable

```powershell
dist_exe\\ajustarImagenesTienda.exe ruta\\imagen.jpg
dist_exe\\ajustarImagenesTienda.exe carpeta_imagenes carpeta_salida --margen 80
```

Notas
- El nombre del ejecutable es `ajustarImagenesTienda`; si prefieres otro nombre, edita `build_exe.bat`.
- Si necesitas un icono para el ejecutable, puedes añadir la opción `--icon=miicono.ico` al comando de PyInstaller.

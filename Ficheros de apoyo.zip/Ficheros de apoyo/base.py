""" #!/usr/bin/env python3

import os
import sys
from urllib.parse import parse_qs
from Actividad import Actividad


def main():

    query: str = os.environ.get("QUERY_STRING","")
    #long: int = int(os.environ.get("CONTENT_LENGTH","0") or "0")
    #queryBytes=sys.stdin.buffer.read(long)
    #query: str=queryBytes.decode("utf-8")
    
    parametros= parse_qs(query)
    codigo=parametros.get("codigo",[""])[0]
    nombre=parametros.get("nombre",[""])[0]
    categoria=parametros.get("categoria",[""])[0]
    precio=float(parametros.get("precio",["0.0"])[0])
    edadMinima=int(parametros.get("edadMinima",["0"])[0])
    reservas=int(parametros.get("reservas",["0"])[0])

    actividades: list[Actividad]=[]
    actividades.append(Actividad("a01","Tirolina gigante","ciudad",25.0,12,15))
    actividades.append(Actividad("a02","Tomar el sol","playa",30.0,5,15))
    actividades.append(Actividad("a03","Catedral","montaña",45.0,18,15))

    seleccionadas:list[Actividad]=[]

    for a in actividades:
         if a.codigo==codigo or a.nombre==nombre or a.categoria==categoria:
              if a.puedeReservar(edadMinima,reservas):
                   seleccionadas.append(a)
 """




# Cabecera HTTP
print("Content-Type: text/html; charset=utf-8")
print()

# Documento HTML
print("<!DOCTYPE html>")
print('<html lang="es">')
print("<head>")
print('    <meta charset="UTF-8">')
print("    <title>Mi página web</title>")
print("</head>")
print("<body>")

# Contenido dinámico de la página
print("    <h1>Mi primera página CGI</h1>")
print("    <p>Contenido generado desde Python</p>")

# Cierre del documento
print("</body>")
print("</html>")
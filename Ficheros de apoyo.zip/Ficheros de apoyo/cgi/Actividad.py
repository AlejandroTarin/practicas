class Actividad:
    def __init__(self,codigo:str,nombre:str,categoria:str,precio:float,edadMinima:int,plazasDisponibles:int):
        self.codigo=codigo
        self.nombre=nombre
        self.categoria=categoria
        self.precio=precio
        self.edadMinima=edadMinima
        self.plazasDisponibles=plazasDisponibles

def puedeReservar(self,edad:int,participantes:int)->bool:
    if edad>self.edadMinima and participantes>0 and participantes<=self.plazasDisponibles:
        return True
    else:
        return False

def calcularImporte (self, participantes:int)->float:
    if participantes < 3:
        return self.precio
    elif participantes<6:
        return self.precio * 0.9
    else:
        return self.precio * 0.85

class Libro:
    def __init__(self, titulo:str,autor:str,precio:float,stock:int):
        self.titulo=titulo
        self.autor=autor
        self.precio=precio
        self.stock=stock


    def disponible(self)->bool:
        if self.stock>0:
            return True
        else:
            return False

    def valorStock(self)->float:
        return self.precio * self.stock

    


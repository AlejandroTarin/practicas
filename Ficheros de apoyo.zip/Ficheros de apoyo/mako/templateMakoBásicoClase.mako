# Documento HTML
<!DOCTYPE html> 
<html lang="es">'
    <head> 
        <meta charset="UTF-8">'
        <title>Mi página web</title> 
    </head> 
 <body> 
# Contenido dinámico de la página
     <h1>Mi primera página CGI</h1> 
     <p>Contenido generado desde Python</p> 


<table border=1>
<tr>
<th>Titulo</th>
<th>Autor</th>
<th>Precio</th>
<th>disponiblilidad</th>
<th>valor stock</th>
</tr>

%for l in lista
    <tr>
        <td>${l.titulo}</td>
        <td>${l.autor}</td>
        <td>${l.titulo}</td>
        <td>%if l.disponible():
                disponible
            %else:
                no dispobible  
            %endif
        </td>
        <td>${l.valorStock()}</td>

    </tr>


%endfor

</table>
# Cierre del documento
 </body> 
 </html> 
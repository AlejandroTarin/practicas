#! usr/bin/env python3

import sys
import os
from urllib.parse import parse_qs
from mako.templates import Template

#imports 
from mako import exceptions
from Libro import Libro

def main():
    lon = int(os.environ.get("CONTENT_LENGTH","0")or "0")
    query =sys.stdin.buffer.read(lon).decode("utf-8")
    parametros = parse_qs(query)

    listaLibros: list [Libro]=[]

    l:Libro

    for i in range(0,4):
        l=Libro(
            parametros.get("titulo",[""])[i],
            parametros.get("autor",[""])[i],
            float(parametros.get("precio",["0"])[i]),
            int(parametros.get("stock",["0"])[i]),
        )
    listaLibros.append(l)


    plantilla = Template(
        filename="/app/templatesMako/libros.mako",
                        input_encoding="utf-8",
                        default_filters=["h"]
    )

    



    #atributos del constructor del objeto Template 
    #                     filename="/app/templatesMako/xxxxxx.mako",
    #                     input_encoding="utf-8",
    #                     default_filters=["h"])



    #renderizar
    try:
            html=plantilla.render(
                #parametros
                lista = listaLibros
            
            )
    except Exception:
            print(exceptions.text_error_template().render(), file=sys.stderr)
            print("Content-Type: text/plain; charset=utf-8")
            print()
            print("Error al generar la página. Consulta los logs.")
            return 
    
        #cabecera
    print("Content-Type: text/plain; charset=utf-8")
    print(html)
    # Para ver los 50 ultimos errores que captura la excepcion ejecutar en el terminal esta instrucción

    # docker compose logs --tail=50 cgi 

    #para ver los ultimos errores en tiempo real

    # docker compose logs --tail=0 -f cgi

    # En cada ejecución saldra una nueva cola de errores. Hay que buscar los últimos para ver en que linea del codigo mako tienes un error

if __name__ =="__main__":
    main()
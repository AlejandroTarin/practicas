
from AppEmergencias import contenido as contenido_emergencias #completar 
from AppPrecipitaciones import contenido as contenido_precipitaciones

def application(environ, start_response):
    # Rutas disponibles: añadir una entrada por cada ejercicio.
    rutas = {
        "/precipitaciones": contenido_precipitaciones,
        "/emergencias": contenido_emergencias  #agregar ruta de la app

      # "/calculadora": contenido_calculadora
}
    ruta: str = environ.get("PATH_INFO", "/")
    estado: str = "200 OK"
    contenido: str

    if ruta == "/":
        contenido = "<h1>El servicio WSGI funciona correctamente</h1>"
    elif ruta in rutas:
        contenido = rutas[ruta](environ)
    else:
        estado = "404 Not Found"
        contenido = "<h1>No existe esa ruta</h1>"

    html: str = f"""<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Pruebas WSGI</title>
</head>
<body>
    {contenido}
</body>
</html>"""
    respuesta: bytes = html.encode("utf-8")

    start_response(
        estado,
        [
            ("Content-Type", "text/html; charset=utf-8"),
            ("Content-Length", str(len(respuesta)))
        ]
    )

    return [respuesta]

#docker compose logs --tail=50 wsgi  #lista 50 últimos errores  
#docker compose logs --tail=1m wsgi  #lista errores  ultimo minuto
#docker compose logs -f wsgi #Visualizar en terminal lo que se imprime por medio de print


class Vehiculo:
    def __init__(self, codigo:str,tipo:str,capacidad:int,disponibilidad:bool):
        self.codigo=codigo
        self.tipo=tipo
        self.capacidad=capacidad
        self.disponible=disponibilidad
    def puedeAtender (self, num:int, tipointervencion:str)->bool:
        if not self.disponible:
            return True
        
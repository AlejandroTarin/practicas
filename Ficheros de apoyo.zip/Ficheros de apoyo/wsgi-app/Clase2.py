class Municipio:
    def __init__(self, nombre: str, precipitacion: float):
        self.nombre = nombre
        self.precipitacion = precipitacion
        self.nivel_alarma = self.calcular_alarma(precipitacion)

    @staticmethod
    def calcular_alarma(precipitacion: float) -> str:
        if precipitacion > 400:
            return "Alarma roja"
        elif precipitacion >= 251:  # Entre 251 y 400 ambos incluidos
            return "Alarma naranja"
        elif precipitacion >= 101:  # Entre 101 y 250
            return "Alarma amarilla"
        else:
            return "Sin alarma"
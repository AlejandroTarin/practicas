from urllib.parse import parse_qs
from Municipio import Municipio

def contenido(environ) -> str:
    # 1. Leer cuerpo de la petición POST
    longitud = int(environ.get("CONTENT_LENGTH", "0") or "0")
    cuerpo = environ.get("wsgi.input")
    query = cuerpo.read(longitud).decode("utf-8")
    
    # 2. Parsear parámetros recibidos del formulario
    parametros = parse_qs(query)

    nombres = parametros.get("nombre", [])
    precipitaciones = parametros.get("precipitacion", [])

    lista_municipios: list[Municipio] = []
    suma_precipitaciones = 0.0
    total_lecturas = 5

    # 3. Procesar las 5 lecturas enviadas por el formulario
    for i in range(total_lecturas):
        nombre = nombres[i] if i < len(nombres) and nombres[i] else f"Municipio {i+1}"
        try:
            precip = float(precipitaciones[i]) if i < len(precipitaciones) and precipitaciones[i] else 0.0
        except ValueError:
            precip = 0.0

        suma_precipitaciones += precip
        m = Municipio(nombre, precip)
        lista_municipios.append(m)

    # 4. Filtrar municipios que están en estado de alarma (> 100 l/m²)
    municipios_en_alarma = [m for m in lista_municipios if m.nivel_alarma != "Sin alarma"]

    # 5. Calcular la media de la cuenca y su estado de alarma global
    media_cuenca = suma_precipitaciones / total_lecturas if total_lecturas > 0 else 0.0
    alarma_cuenca = Municipio.calcular_alarma(media_cuenca)

    # 6. Construir el HTML de respuesta dinámicamente
    html = """
    <h2>Informe de Precipitaciones y Estado de Alarma</h2>
    
    <h3>1. Listado de Municipios en Estado de Alarma</h3>
    """

    if len(municipios_en_alarma) == 0:
        html += "<p>No hay ningún municipio en estado de alarma actualmente.</p>"
    else:
        html += "<ul>"
        for m in municipios_en_alarma:
            html += f"<li><strong>{m.nombre}</strong>: {m.precipitacion} l/m² — <em>{m.nivel_alarma}</em></li>"
        html += "</ul>"

    html += f"""
    <h3>2. Estado de Alarma del Conjunto de la Cuenca</h3>
    <p><strong>Precipitación media de la cuenca:</strong> {media_cuenca:.2f} l/m²</p>
    """

    if alarma_cuenca == "Sin alarma":
        html += "<p><strong>Estado global de la cuenca:</strong> No existe alarma.</p>"
    else:
        html += f"<p><strong>Estado global de la cuenca:</strong> <span style='color:red;'>{alarma_cuenca}</span></p>"

    return html
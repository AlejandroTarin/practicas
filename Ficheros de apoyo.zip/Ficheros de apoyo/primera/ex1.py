from Creador import Creador


#Metodo inicializar
def inicializar (creadores: dict[str,Creador]):
    c1=Creador("aa","aaaa","Gaming")
    c2=Creador("ab","aabb","Gaming")
    c3=Creador("ac","bbcc","Gaming")
    c4=Creador("bb","bbbb","Coches")
    c5=Creador("ba","ccbb","Deportes")

    creadores[c1.nick]=c1
    creadores[c2.nick]=c2
    creadores[c3.nick]=c3
    creadores[c4.nick]=c4
    creadores[c5.nick]=c5

def menu():
    print("""
            APLICACION CREADORES
            1.Insertat
            2.Buscar por nick
            3.Borrar por nick
            4.Listar por genero
            5.Modificar nick creador
            0.SALIR
            """)
    
def introducir()->Creador:
    c=Creador("","","Gaming")
    c.nombre=input("nombre?")
    c.nick=input("nick?")
    continuar=True
    while continuar:
        try:
            c.genero=input("genero?")
            continuar=False
        except ValueError as e:
            print(e)
    return c

def buscar (creadores):
    nick=input("nick?")
    if nick in creadores:
        c: Creador=creadores[nick]
        c.imprimir()
    else:
        print("no existe")

def borrar(creadores):
    nick=input("que nick quieres borrar?")
    c: Creador |None =creadores.get(nick,None)
    if c==None:
        print("no existe")
    else:
        del creadores[nick]
        print(f"Eliminado: {nick}")


def insertar(creadores:dict[str,Creador]):
    #introducir datos de objeto Creador
    c=introducir()
    #Comprobar que no existe
    if c.nick in creadores:
        print("no se puede introducir pq ya existe")
        return
    else:
        creadores[c.nick]=c
    #Crear un objeto Creador + Excepciones

def main():
    #Diccionario de creadores
    creadores:dict[str,Creador]={}
    inicializar(creadores)
    continuar:bool=True
    opcion:int
    while(continuar):
        menu()
        opcion=int(input("Introduce opcion"))
        if opcion == 0:
            continuar=False
            continue
        elif opcion==1:
            insertar(creadores)
        elif opcion==2:
            buscar(creadores)
        elif opcion==3:
            borrar(creadores)

if __name__=="__main__":
    main()


class Creador:
    def __init__(self,nick: str, nombre:str, genero:str):
        self.nombre=nombre
        self.nick=nick
        self.genero=genero

    @property
    def genero (self)->str:
        return self._genero
    @genero.setter
    def genero(self, genero):
        if genero in ["Gaming","Coches","Deportes"]:
            self._genero=genero
        else:
            raise ValueError("Introducir genero valido")
    def calcularCache(self)->float:
        if (self.genero =="Gaming"):
            return 3000
        elif (self.genero == "Coches"):
            return 3500
        elif (self.genero == "Deportes"):
            return 4500
        else:
            return -1

    def imprimir(self):
        print (f"nombre: {self.nombre}, nick: {self.nick}, genero: {self.genero}")

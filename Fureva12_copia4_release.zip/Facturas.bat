@echo off
cd /d "%~dp0"
:: 0 = Fondo Negro, A = Verde Brillante
color 0A
cls
title Generador FacturaE
node index.js
echo.
pause

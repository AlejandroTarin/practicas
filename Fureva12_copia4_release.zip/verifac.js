const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

/**
 * Genera el XML SOAP VeriFactu a partir de un fichero Facturae.
 * @param {string} facturaePath Ruta absoluta al fichero .xml de Facturae.
 */
function generateVerifac(facturaePath) {
    try {
        console.log(`[VERIFAC] Procesando factura: ${path.basename(facturaePath)}`);
        
        // 1. Leer fichero y calcular huella SHA-256
        const buffer = fs.readFileSync(facturaePath);
        const huella = crypto.createHash('sha256').update(buffer).digest('hex').toUpperCase();
        const content = buffer.toString('utf8');

        // 2. Extraer datos con Regex (al no disponer de parser XML robusto en este entorno)
        const getTag = (xml, tag) => {
            const match = xml.match(new RegExp(`<fe:${tag}[^>]*>([\\s\\S]*?)</fe:${tag}>`)) || 
                          xml.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`));
            return match ? match[1].trim() : '';
        };

        const sellerXml = getTag(content, 'SellerParty');
        const buyerXml = getTag(content, 'BuyerParty');
        const invoicesXml = getTag(content, 'Invoices');
        const invoiceXml = getTag(invoicesXml, 'Invoice');
        const headerXml = getTag(invoiceXml, 'InvoiceHeader');
        const issueDataXml = getTag(invoiceXml, 'InvoiceIssueData');
        const totalsXml = getTag(invoiceXml, 'InvoiceTotals');

        // Seller data
        const sellerNif = getTag(sellerXml, 'TaxIdentificationNumber');
        const sellerNombre = getTag(sellerXml, 'CorporateName');

        // Invoice data
        const numFactura = getTag(headerXml, 'InvoiceNumber').substring(0, 60);
        const fechaFactura = getTag(issueDataXml, 'IssueDate');

        // Buyer data
        let buyerNif = getTag(buyerXml, 'TaxIdentificationNumber');
        let buyerNombre = '';

        if (buyerXml.includes('<fe:LegalEntity>') || buyerXml.includes('<LegalEntity>')) {
            buyerNombre = getTag(buyerXml, 'CorporateName');
        } else if (buyerXml.includes('<fe:Individual>') || buyerXml.includes('<Individual>')) {
            const nombre = getTag(buyerXml, 'Name');
            const ape1 = getTag(buyerXml, 'FirstSurname');
            const ape2 = getTag(buyerXml, 'SecondSurname');
            buyerNombre = [nombre, ape1, ape2].filter(x => x && x !== ' ').join(' ').trim();
        }

        // Taxes extraction
        const taxesOutputsXml = getTag(invoiceXml, 'TaxesOutputs');
        const taxBlockRegex = /<(?:fe:)?Tax>([\s\S]*?)<\/(?:fe:)?Tax>/g;
        let desgloseXml = '';
        let match;
        
        while ((match = taxBlockRegex.exec(taxesOutputsXml)) !== null) {
            const taxXml = match[1];
            const rate = getTag(taxXml, 'TaxRate');
            const baseXml = getTag(taxXml, 'TaxableBase');
            const base = getTag(baseXml, 'TotalAmount');
            const amountXml = getTag(taxXml, 'TaxAmount');
            const amount = getTag(amountXml, 'TotalAmount');

            desgloseXml += `                    <sum1:DetalleDesglose>
                        <sum1:ClaveRegimen>01</sum1:ClaveRegimen>
                        <sum1:CalificacionOperacion>S1</sum1:CalificacionOperacion>
                        <sum1:TipoImpositivo>${rate}</sum1:TipoImpositivo>
                        <sum1:BaseImponibleOImporteNoSujeto>${base}</sum1:BaseImponibleOImporteNoSujeto>
                        <sum1:CuotaRepercutida>${amount}</sum1:CuotaRepercutida>
                    </sum1:DetalleDesglose>\n`;
        }

        const cuotaTotal = getTag(totalsXml, 'TotalTaxOutputs');
        const importeTotal = getTag(totalsXml, 'InvoiceTotal');

        // 3. Validaciones
        if (!sellerNif || !numFactura || !fechaFactura) {
            throw new Error('Faltan campos obligatorios en el Facturae (NIF Emisor, Num Factura o Fecha).');
        }

        // 4. Construir SOAP
        const now = new Date();
        const pad = (n) => n.toString().padStart(2, '0');
        const offset = -now.getTimezoneOffset();
        const diff = offset >= 0 ? '+' : '-';
        const tz = diff + pad(Math.floor(Math.abs(offset) / 60)) + ':' + pad(Math.abs(offset) % 60);
        const currentDateTime = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}T${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}${tz}`;

        const soap = `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
    xmlns:sum1="https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/tike/cont/ws/SuministroInformacion.xsd"
    xmlns:sum="https://www2.agenciatributaria.gob.es/static_files/common/internet/dep/aplicaciones/es/aeat/tike/cont/ws/SuministroLR.xsd">
    <soapenv:Header/>
    <soapenv:Body>
        <sum:RegTicketSii>
            <sum1:ObligadoEmision>
                <sum1:NombreRazon>${sellerNombre}</sum1:NombreRazon>
                <sum1:NIF>${sellerNif}</sum1:NIF>
            </sum1:ObligadoEmision>
            <sum1:SistemaInformatico>
                <sum1:NombreRazon>${sellerNombre}</sum1:NombreRazon>
                <sum1:NIF>${sellerNif}</sum1:NIF>
                <sum1:IdSistemaInformatico>VF</sum1:IdSistemaInformatico>
                <sum1:NombreSistemaInformatico>VTIME SOFTWARE</sum1:NombreSistemaInformatico>
                <sum1:Version>1.0</sum1:Version>
            </sum1:SistemaInformatico>
            <sum1:FechaHoraHusoGenRegistro>${currentDateTime}</sum1:FechaHoraHusoGenRegistro>
            <sum1:NumeroEnvio>1</sum1:NumeroEnvio>
            <sum1:RefExterna>${numFactura}</sum1:RefExterna>
            <sum:RegistroAlta>
                <sum1:IDVersion>1.0</sum1:IDVersion>
                <sum1:IDFactura>
                    <sum1:IDEmisorFactura>${sellerNif}</sum1:IDEmisorFactura>
                    <sum1:NumSerieFactura>${numFactura}</sum1:NumSerieFactura>
                    <sum1:FechaExpedicionFactura>${fechaFactura}</sum1:FechaExpedicionFactura>
                </sum1:IDFactura>
                <sum1:NombreRazonEmisor>${sellerNombre}</sum1:NombreRazonEmisor>
                <sum1:TipoFactura>F1</sum1:TipoFactura>
                <sum1:DescripcionOperacion>Prestacion de servicios funerarios</sum1:DescripcionOperacion>
                <sum1:Destinatarios>
                    <sum1:IDDestinatario>
                        <sum1:NombreRazon>${buyerNombre}</sum1:NombreRazon>
                        <sum1:NIF>${buyerNif}</sum1:NIF>
                    </sum1:IDDestinatario>
                </sum1:Destinatarios>
                <sum1:Desglose>
${desgloseXml.trimEnd()}
                </sum1:Desglose>
                <sum1:CuotaTotal>${cuotaTotal}</sum1:CuotaTotal>
                <sum1:ImporteTotal>${importeTotal}</sum1:ImporteTotal>
                <sum1:Encadenamiento>
                    <sum1:PrimerRegistro>S</sum1:PrimerRegistro>
                </sum1:Encadenamiento>
                <sum1:SistemaInformatico>
                    <sum1:NombreRazon>${sellerNombre}</sum1:NombreRazon>
                    <sum1:NIF>${sellerNif}</sum1:NIF>
                    <sum1:IdSistemaInformatico>VF</sum1:IdSistemaInformatico>
                    <sum1:NombreSistemaInformatico>VTIME SOFTWARE</sum1:NombreSistemaInformatico>
                    <sum1:Version>1.0</sum1:Version>
                </sum1:SistemaInformatico>
                <sum1:FechaHoraHusoGenRegistro>${currentDateTime}</sum1:FechaHoraHusoGenRegistro>
                <sum1:TipoHuella>01</sum1:TipoHuella>
                <sum1:Huella>${huella}</sum1:Huella>
            </sum:RegistroAlta>
        </sum:RegTicketSii>
    </soapenv:Body>
</soapenv:Envelope>`;

        // 5. Escribir fichero
        const fileName = path.basename(facturaePath);
        const outName = fileName.replace(/(\.xml)$/i, '_verifac$1');
        const outPath = path.join(path.dirname(facturaePath), outName);
        
        fs.writeFileSync(outPath, soap, 'utf8');
        console.log(`[VERIFAC] OK -> ${outName}`);

    } catch (error) {
        console.error(`[VERIFAC ERROR] ${error.message}`);
    }
}

module.exports = { generateVerifac };

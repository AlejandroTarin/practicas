const { execSync } = require('child_process');

// Esto fuerza a la consola de Windows a ponerse en verde al arrancar
try {
    execSync('color 0A', { stdio: 'inherit' });
} catch (e) {
    // Si falla (por ejemplo en Mac/Linux), que no rompa el programa
}

console.log("Iniciando programa en verde...");


const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { generateVerifac } = require('./verifac');

// CONFIGURACIÓN DE RUTAS
const BASE_DIR = process.cwd();
const DIR_SALIDA = path.join(BASE_DIR, 'XML_GENERADOS');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Helper: convierte rl.question en una Promise
function askQuestion(query) {
    return new Promise(resolve => rl.question(query, resolve));
}

// Valida formato DD/MM/AAAA y devuelve Date o null
function parseDateDDMMYYYY(str) {
    const m = str.trim().match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    if (!m) return null;
    const d = new Date(`${m[3]}-${m[2]}-${m[1]}`);
    return isNaN(d.getTime()) ? null : d;
}

// Normaliza fecha de VTIME01 ("DD-MM-AAAA") a Date
function parseDateVtime(str) {
    if (!str || !str.includes('-')) return null;
    const p = str.trim().split('-');
    if (p.length !== 3) return null;
    const d = new Date(`${p[2]}-${p[1]}-${p[0]}`);
    return isNaN(d.getTime()) ? null : d;
}

// Busca en VTIME01 los num_servicio que coinciden con el criterio
function findMatchingServiceIds(v01, mode, value1, value2) {
    const ids = [];
    const lines = v01.split('\n');
    for (const line of lines) {
        if (!line.trim()) continue;
        const cols = parseCSVLine(line);
        if (!cols[0]) continue;
        switch (mode) {
            case '1': { // Número de Servicio (ID numérico)
                const id = !isNaN(cols[0]) ? parseFloat(cols[0]).toString() : cols[0];
                const target = !isNaN(value1) ? parseFloat(value1).toString() : value1;
                if (id === target) ids.push(id);
                break;
            }
            case '2': { // Número de Factura (ej. 196/2018)
                const numFact = cols[3] ? cols[3].trim() : '';
                if (numFact === value1.trim()) {
                    const id = !isNaN(cols[0]) ? parseFloat(cols[0]).toString() : cols[0];
                    ids.push(id);
                }
                break;
            }
            case '3': { // Fecha exacta
                const fechaVtime = parseDateVtime(cols[1]);
                if (fechaVtime && fechaVtime.getTime() === value1.getTime()) {
                    const id = !isNaN(cols[0]) ? parseFloat(cols[0]).toString() : cols[0];
                    ids.push(id);
                }
                break;
            }
            case '4': { // Rango de fechas
                const fechaVtime = parseDateVtime(cols[1]);
                if (fechaVtime && fechaVtime >= value1 && fechaVtime <= value2) {
                    const id = !isNaN(cols[0]) ? parseFloat(cols[0]).toString() : cols[0];
                    ids.push(id);
                }
                break;
            }
        }
    }
    return ids;
}

// CONFIGURACIÓN DE EMISOR (Cargada desde VTIME00.txt)
let CONFIG_EMISOR = {
    NIF: "B46622619",
    Nombre: "FUNERARIA VTIME",
    Direccion: "PERIS Y VALERO 135",
    CP: "46005",
    Pueblo: "VALENCIA",
    Provincia: "VALENCIA"
};

function loadEmisorConfig() {
    const v00Path = path.join(process.cwd(), 'VTIME00.txt');
    if (fs.existsSync(v00Path)) {
        const content = fs.readFileSync(v00Path, 'utf8');
        const lines = content.split('\n');
        if (lines[0]) {
            const cols = parseCSVLine(lines[0]);
            CONFIG_EMISOR = {
                NIF: cols[0] || CONFIG_EMISOR.NIF,
                Nombre: (cols[1] || CONFIG_EMISOR.Nombre).trim(),
                Direccion: (cols[3] || CONFIG_EMISOR.Direccion).trim(),
                CP: (cols[4] || CONFIG_EMISOR.CP).trim(),
                Pueblo: (cols[5] || CONFIG_EMISOR.Pueblo).trim(),
                Provincia: (cols[6] || CONFIG_EMISOR.Provincia).trim()
            };
            console.log(`[INIT] Emisor cargado: ${CONFIG_EMISOR.Nombre}`);
        }
    }
}

// Utilidades de limpieza
function cleanValue(val) {
    if (!val) return '';
    return val.trim().replace(/^"|"$/g, '').trim();
}

function parseCSVLine(line) {
    if (!line.includes('","')) return line.split(',').map(v => cleanValue(v));
    return line.split('","').map(v => cleanValue(v));
}

function formatDateToISO(dateStr) {
    if (!dateStr || !dateStr.includes('-')) return dateStr;
    const parts = dateStr.split('-');
    return (parts.length === 3 && parts[0].length === 2) ? `${parts[2]}-${parts[1]}-${parts[0]}` : dateStr;
}

async function start() {
    loadEmisorConfig();
    const argId = process.argv[2];

    if (argId) {
        // Ejecución desde .bat con parámetros (num_servicio directo)
        console.log(`[BAT] Procesando Número de Servicio: ${argId.trim()}`);
        try { processTask(argId.trim()); }
        catch (err) { console.error(`\n[ERROR] ${err.message}`); }
        rl.close();
        return;
    }

    // ---- MENÚ INTERACTIVO ----
    let salir = false;
    while (!salir) {
        console.log("\n==========================================");
        console.log("    CONVERSOR FACTURAE v2 (FORMATO XML)");
        console.log("==========================================");
        console.log("  1. Búsqueda por Número de Servicio");
        console.log("  2. Búsqueda por Número de Factura  (ej: 196/2018)");
        console.log("  3. Búsqueda por Fecha Exacta       (ej: 25/09/2023)");
        console.log("  4. Búsqueda por Rango de Fechas");
        console.log("  0. Salir");
        console.log("------------------------------------------");

        const opcion = (await askQuestion('  Seleccione una opción: ')).trim();

        if (opcion === '0') {
            console.log('[INFO] Saliendo...');
            salir = true;
            break;
        }

        if (!['1', '2', '3', '4'].includes(opcion)) {
            console.log('[AVISO] Opción no válida. Introduzca un número del 0 al 4.');
            continue;
        }

        // Leer los archivos VTIME01 una sola vez para la búsqueda
        const v01Path = path.join(BASE_DIR, 'VTIME01.txt');
        if (!fs.existsSync(v01Path)) {
            console.error('[ERROR] No se encontró VTIME01.txt');
            continue;
        }
        const v01 = fs.readFileSync(v01Path, 'utf8');

        let matchIds = [];

        if (opcion === '1') {
            const numServicio = (await askQuestion('  Introduzca el Número de Servicio (ej: 1104): ')).trim();
            if (!numServicio) { console.log('[AVISO] Valor vacío.'); continue; }
            matchIds = findMatchingServiceIds(v01, '1', numServicio);
        }

        else if (opcion === '2') {
            const numFactura = (await askQuestion('  Introduzca el Número de Factura (ej: 196/2018): ')).trim();
            if (!numFactura.includes('/')) {
                console.log('[AVISO] Formato incorrecto. Use el formato con barra: 196/2018');
                continue;
            }
            matchIds = findMatchingServiceIds(v01, '2', numFactura);
        }

        else if (opcion === '3') {
            const fechaStr = (await askQuestion('  Introduzca la fecha (DD/MM/AAAA): ')).trim();
            const fecha = parseDateDDMMYYYY(fechaStr);
            if (!fecha) {
                console.log('[AVISO] Formato de fecha incorrecto. Use DD/MM/AAAA (ej: 25/09/2023)');
                continue;
            }
            matchIds = findMatchingServiceIds(v01, '3', fecha);
        }

        else if (opcion === '4') {
            const fechaIniStr = (await askQuestion('  Fecha de inicio (DD/MM/AAAA): ')).trim();
            const fechaIni = parseDateDDMMYYYY(fechaIniStr);
            if (!fechaIni) { console.log('[AVISO] Fecha de inicio incorrecta. Use DD/MM/AAAA'); continue; }

            const fechaFinStr = (await askQuestion('  Fecha de fin    (DD/MM/AAAA): ')).trim();
            const fechaFin = parseDateDDMMYYYY(fechaFinStr);
            if (!fechaFin) { console.log('[AVISO] Fecha de fin incorrecta. Use DD/MM/AAAA'); continue; }

            if (fechaFin < fechaIni) { console.log('[AVISO] La fecha de fin no puede ser anterior a la de inicio.'); continue; }
            matchIds = findMatchingServiceIds(v01, '4', fechaIni, fechaFin);
        }

        // Procesar los resultados encontrados
        if (matchIds.length === 0) {
            console.log('[AVISO] No se encontraron registros con ese criterio.');
        } else {
            console.log(`\n[INFO] ${matchIds.length} servicio(s) encontrado(s). Generando XML...`);
            let ok = 0, errores = 0;
            for (const sid of matchIds) {
                try {
                    processTask(sid);
                    ok++;
                } catch (err) {
                    console.error(`  [ERROR] Servicio ${sid}: ${err.message}`);
                    errores++;
                }
            }
            console.log(`\n[RESUMEN] Generados: ${ok} | Errores: ${errores}`);
        }
    }

    rl.close();
}

function processTask(rawTargetId) {
    const v01Path = path.join(BASE_DIR, 'VTIME01.txt');
    const v03Path = path.join(BASE_DIR, 'VTIME03.txt');

    if (!fs.existsSync(v01Path) || !fs.existsSync(v03Path)) {
        throw new Error(`Faltan archivos VTIME01.txt o VTIME03.txt en: ${BASE_DIR}`);
    }

    const v01 = fs.readFileSync(v01Path, 'utf8');
    const v03 = fs.readFileSync(v03Path, 'utf8');

    // 0. CARGAR DICCIONARIO DE EMPRESAS (VTIME05)
    const v05Path = path.join(BASE_DIR, 'VTIME05.txt');
    const insuranceMap = {};
    if (fs.existsSync(v05Path)) {
        fs.readFileSync(v05Path, 'utf8').split('\n').forEach(l => {
            if (!l.trim()) return;
            const c = parseCSVLine(l);
            const insId = parseFloat(c[0] || "0").toString();
            insuranceMap[insId] = {
                nombre: c[1],
                direccion: c[2],
                cp: c[3],
                pueblo: c[4],
                provincia: c[5],
                nif: c[6]
            };
        });
    }

    // 1. PROCESAR CABECERA (VTIME01)
    const lines01 = v01.split('\n');
    let cabeceraData = null;

    const targetIdSearch = !isNaN(rawTargetId) ? parseFloat(rawTargetId).toString() : rawTargetId;

    for (const line of lines01) {
        if (!line.trim()) continue;
        const cols = parseCSVLine(line);
        if (cols[0]) {
            const id = !isNaN(cols[0]) ? parseFloat(cols[0]).toString() : cols[0];
            if (id === targetIdSearch) {
                // --- Lógica de Selección de Comprador V5 (VTIME05 + Fallback) ---
                const nifRE = /^[A-Z][0-9]{7,8}[A-Z0-9]$|^[0-9]{8}[A-Z]$/;
                const isCoNif = (nif) => /^[A-HJ-NP-SU-W]/.test((nif || "").trim().charAt(0).toUpperCase());
                const isCoNom = (t) => /\b(S\.?L\.?|S\.?A\.?|SEGUROS|MUTUA|GRUPO|GRUOPO|ACTIVE|APOCALIPSIS)\b/i.test(t);
                const isRel = (t) => /\b(HIJA|HIJO|VIUDA|VIUDO|FAMILIAR DE|MADRE|PADRE|HERMANO|HERMANA)\b/i.test(t);

                const insuranceId = parseFloat(cols[5] || "0").toString();
                let best = null;

                // PRIORIDAD 1: Buscar por ID de empresa en VTIME05
                if (insuranceId !== "0" && insuranceId !== "NaN" && insuranceMap[insuranceId]) {
                    const ins = insuranceMap[insuranceId];
                    best = {
                        nif: ins.nif || "B00000000",
                        nombre: ins.nombre,
                        isCo: true,
                        direccion: ins.direccion,
                        cp: ins.cp,
                        pueblo: ins.pueblo,
                        provincia: ins.provincia,
                        idx: 51
                    };
                    console.log(`[OK] Detectada Empresa por ID ${insuranceId} (VTIME05): ${ins.nombre}`);
                }

                // PRIORIDAD 2: Si no hay empresa (0.00), escaneamos la línea buscando persona
                if (!best) {
                    let candidates = [];
                    for (let i = 0; i < cols.length; i++) {
                        const val = cleanValue(cols[i]);
                        if (!val || val === "-  -" || val.length < 2) continue;

                        if (nifRE.test(val)) {
                            const nif = val;
                            const nomIdx = Math.max(0, i - 4);
                            const nameParts = [cols[nomIdx], cols[nomIdx + 1], cols[nomIdx + 2]].map(cleanValue);
                            let fullName = nameParts.join(' ').trim() || "CLIENTE";
                            // Limpiar posibles números o guiones en el nombre
                            fullName = fullName.replace(/^[0-9\.\-\s]+/, '').trim() || "CLIENTE";

                            let score = isCoNif(nif) ? 800 : 100;
                            if (isCoNom(fullName)) score += 300;

                            // Si estamos aquí es porque NO hay empresa aseguradora.
                            // Por tanto, el comprador es casi seguro una persona física (familiar).
                            // Las columnas 51 y 126 son los lugares canónicos donde se guardan.
                            if (i === 126 || i === 51) {
                                score += 5000;
                            }

                            candidates.push({ nif, nombre: fullName, nom: nameParts[0], ape1: nameParts[1], ape2: nameParts[2], isCo: isCoNif(nif), idx: i, score });
                        }
                    }
                    candidates.sort((a, b) => b.score - a.score);
                    const chosen = candidates[0] || { nif: "52745036X", nombre: "CLIENTE DESCONOCIDO", isCo: false, idx: 51 };

                    best = {
                        ...chosen,
                        direccion: cleanValue(cols[chosen.idx + 4]) || "DESCONOCIDA",
                        cp: cleanValue(cols[chosen.idx + 3]) || "00000",
                        pueblo: cleanValue(cols[chosen.idx > 100 ? 141 : 60]) || "DESCONOCIDO",
                        provincia: cleanValue(cols[chosen.idx > 100 ? 127 : 52]) || "DESCONOCIDO"
                    };
                    console.log(`[OK] Detectada Persona Física por Escaneo: ${best.nombre}`);
                }

                const isCo = isCoNif(best.nif) || best.isCo;

                cabeceraData = {
                    id: id,
                    numFacturaVtime: cleanValue(cols[3]) || id, // Formato "189/2018"
                    fecha: cols[1],
                    compradorNombre: best.nombre,
                    compradorNIF: best.nif.substring(0, 9),
                    compradorIsEmpresa: isCo,
                    compradorIndividual: {
                        nombre: best.nom || best.nombre,
                        apellido1: best.ape1 || " ",
                        apellido2: best.ape2 || " "
                    },
                    compradorDireccion: best.direccion.substring(0, 80),
                    compradorCP: best.cp.substring(0, 5),
                    compradorPueblo: best.pueblo.substring(0, 50),
                    compradorProvincia: best.provincia.substring(0, 20)
                };
                break;
            }
        }
    }

    if (!cabeceraData) throw new Error(`El número "${rawTargetId}" no se encontró en VTIME01.txt`);

    // 2. PROCESAR LÍNEAS (VTIME03)
    const lines03 = v03.split('\n');
    const facturaLineas = [];
    const impuestosAgrupados = {};

    lines03.forEach(line => {
        if (!line.trim()) return;
        const cols = parseCSVLine(line);
        const lineId = !isNaN(cols[0]) ? parseFloat(cols[0]).toString() : cols[0];

        if (lineId === cabeceraData.id) {
            const desc = cols[3];
            const base = parseFloat(cols[5]) || 0;
            const tipo = parseFloat(cols[6]) || 0;
            const cuota = (base * (tipo / 100));

            facturaLineas.push({ desc, base, tipo, cuota });

            const k = tipo.toFixed(2);
            if (!impuestosAgrupados[k]) impuestosAgrupados[k] = { tipo: k, base: 0, cuota: 0 };
            impuestosAgrupados[k].base += base;
            impuestosAgrupados[k].cuota += cuota;
        }
    });

    if (facturaLineas.length === 0) throw new Error(`No hay líneas para la factura ${rawTargetId} en VTIME03.txt`);

    // 3. CÁLCULOS TOTALES
    let totalBruto = 0;
    let totalImpuestos = 0;
    for (const k in impuestosAgrupados) {
        totalBruto += impuestosAgrupados[k].base;
        totalImpuestos += impuestosAgrupados[k].cuota;
    }
    const importeTotal = totalBruto + totalImpuestos;

    // 4. GENERAR XML (Formato FacturaE 3.2.1)
    let xmlTaxes = "";
    for (const k in impuestosAgrupados) {
        const imp = impuestosAgrupados[k];
        xmlTaxes += `                <Tax>
                    <TaxTypeCode>01</TaxTypeCode>
                    <TaxRate>${imp.tipo}</TaxRate>
                    <TaxableBase><TotalAmount>${imp.base.toFixed(2)}</TotalAmount></TaxableBase>
                    <TaxAmount><TotalAmount>${imp.cuota.toFixed(2)}</TotalAmount></TaxAmount>
                </Tax>\n`;
    }

    let xmlItems = "";
    facturaLineas.forEach(l => {
        xmlItems += `                <InvoiceLine>
                    <ItemDescription>${l.desc}</ItemDescription>
                    <Quantity>1.0</Quantity>
                    <UnitOfMeasure>01</UnitOfMeasure>
                    <UnitPriceWithoutTax>${l.base.toFixed(2)}</UnitPriceWithoutTax>
                    <TotalCost>${l.base.toFixed(2)}</TotalCost>
                    <GrossAmount>${l.base.toFixed(2)}</GrossAmount>
                    <TaxesOutputs>
                        <Tax>
                            <TaxTypeCode>01</TaxTypeCode>
                            <TaxRate>${l.tipo.toFixed(2)}</TaxRate>
                            <TaxableBase><TotalAmount>${l.base.toFixed(2)}</TotalAmount></TaxableBase>
                            <TaxAmount><TotalAmount>${l.cuota.toFixed(2)}</TotalAmount></TaxAmount>
                        </Tax>
                    </TaxesOutputs>
                </InvoiceLine>\n`;
    });

    const personTypeCode = /^[0-9KLMXYZ]/i.test(cabeceraData.compradorNIF) ? 'F' : 'J';

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<fe:Facturae xmlns:fe="http://www.facturae.es/Facturae/2014/v3.2.1/Facturae" xmlns:ds="http://www.w3.org/2000/09/xmldsig#">
    <FileHeader>
        <SchemaVersion>3.2.1</SchemaVersion>
        <Modality>I</Modality>
        <InvoiceIssuerType>EM</InvoiceIssuerType>
        <Batch>
            <BatchIdentifier>${CONFIG_EMISOR.NIF}${cabeceraData.id.replace(/\W/g, '')}</BatchIdentifier>
            <InvoicesCount>1</InvoicesCount>
            <TotalInvoicesAmount>
                <TotalAmount>${importeTotal.toFixed(2)}</TotalAmount>
            </TotalInvoicesAmount>
            <TotalOutstandingAmount>
                <TotalAmount>${importeTotal.toFixed(2)}</TotalAmount>
            </TotalOutstandingAmount>
            <TotalExecutableAmount>
                <TotalAmount>${importeTotal.toFixed(2)}</TotalAmount>
            </TotalExecutableAmount>
            <InvoiceCurrencyCode>EUR</InvoiceCurrencyCode>
        </Batch>
    </FileHeader>
    <Parties>
        <SellerParty>
            <TaxIdentification>
                <PersonTypeCode>J</PersonTypeCode>
                <ResidenceTypeCode>R</ResidenceTypeCode>
                <TaxIdentificationNumber>${CONFIG_EMISOR.NIF}</TaxIdentificationNumber>
            </TaxIdentification>
            <LegalEntity>
                <CorporateName>${CONFIG_EMISOR.Nombre}</CorporateName>
                <RegistrationData><Book>0</Book></RegistrationData>
                <AddressInSpain>
                    <Address>${CONFIG_EMISOR.Direccion}</Address>
                    <PostCode>${CONFIG_EMISOR.CP}</PostCode>
                    <Town>${CONFIG_EMISOR.Pueblo}</Town>
                    <Province>${CONFIG_EMISOR.Provincia}</Province>
                    <CountryCode>ESP</CountryCode>
                </AddressInSpain>
            </LegalEntity>
        </SellerParty>
        <BuyerParty>
            <TaxIdentification>
                <PersonTypeCode>${personTypeCode}</PersonTypeCode>
                <ResidenceTypeCode>R</ResidenceTypeCode>
                <TaxIdentificationNumber>${cabeceraData.compradorNIF}</TaxIdentificationNumber>
            </TaxIdentification>
            ${cabeceraData.compradorIsEmpresa ? `
            <LegalEntity>
                <CorporateName>${cabeceraData.compradorNombre}</CorporateName>
                <RegistrationData><Book>0</Book></RegistrationData>
                <AddressInSpain>
                    <Address>${cabeceraData.compradorDireccion}</Address>
                    <PostCode>${cabeceraData.compradorCP}</PostCode>
                    <Town>${cabeceraData.compradorPueblo}</Town>
                    <Province>${cabeceraData.compradorProvincia}</Province>
                    <CountryCode>ESP</CountryCode>
                </AddressInSpain>
            </LegalEntity>` : `
            <Individual>
                <Name>${cabeceraData.compradorIndividual.nombre}</Name>
                <FirstSurname>${cabeceraData.compradorIndividual.apellido1}</FirstSurname>
                <SecondSurname>${cabeceraData.compradorIndividual.apellido2}</SecondSurname>
                <AddressInSpain>
                    <Address>${cabeceraData.compradorDireccion}</Address>
                    <PostCode>${cabeceraData.compradorCP}</PostCode>
                    <Town>${cabeceraData.compradorPueblo}</Town>
                    <Province>${cabeceraData.compradorProvincia}</Province>
                    <CountryCode>ESP</CountryCode>
                </AddressInSpain>
            </Individual>`}
        </BuyerParty>
    </Parties>
    <Invoices>
        <Invoice>
            <InvoiceHeader>
                <InvoiceNumber>${cabeceraData.numFacturaVtime}</InvoiceNumber>
                <InvoiceDocumentType>FC</InvoiceDocumentType>
                <InvoiceClass>OO</InvoiceClass>
            </InvoiceHeader>
            <InvoiceIssueData>
                <IssueDate>${formatDateToISO(cabeceraData.fecha)}</IssueDate>
                <InvoiceCurrencyCode>EUR</InvoiceCurrencyCode>
                <TaxCurrencyCode>EUR</TaxCurrencyCode>
                <LanguageName>es</LanguageName>
            </InvoiceIssueData>
            <TaxesOutputs>
${xmlTaxes.trimEnd()}
            </TaxesOutputs>
            <InvoiceTotals>
                <TotalGrossAmount>${totalBruto.toFixed(2)}</TotalGrossAmount>
                <TotalGrossAmountBeforeTaxes>${totalBruto.toFixed(2)}</TotalGrossAmountBeforeTaxes>
                <TotalTaxOutputs>${totalImpuestos.toFixed(2)}</TotalTaxOutputs>
                <TotalTaxesWithheld>0.00</TotalTaxesWithheld>
                <InvoiceTotal>${importeTotal.toFixed(2)}</InvoiceTotal>
                <TotalOutstandingAmount>${importeTotal.toFixed(2)}</TotalOutstandingAmount>
                <TotalExecutableAmount>${importeTotal.toFixed(2)}</TotalExecutableAmount>
            </InvoiceTotals>
            <Items>
${xmlItems.trimEnd()}
            </Items>
        </Invoice>
    </Invoices>
</fe:Facturae>`;

    if (!fs.existsSync(DIR_SALIDA)) fs.mkdirSync(DIR_SALIDA);
    const safeFactura = cabeceraData.numFacturaVtime.replace(/[\/\\]/g, '_').trim();
    const fileName = `Factura_${safeFactura}.xml`;
    const finalPath = path.join(DIR_SALIDA, fileName);
    fs.writeFileSync(finalPath, xml, 'utf8');

    // Generación automática del fichero VeriFactu
    generateVerifac(finalPath);

    console.log(`\n[EXITO] Factura ${cabeceraData.numFacturaVtime} generada correctamente.`);
    console.log(`[ARCHIVO] ${fileName}`);
    console.log(`[TOTAL] ${importeTotal.toFixed(2)} EUR`);
}

start();

